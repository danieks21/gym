"""
========================================================================================
CAPA DE SERVICIOS Y LÓGICA DE NEGOCIO (SRP, SAGA, IDEMPOTENCIA, COMPENSACIÓN INVERSA)
Cátedra: Ingeniería de Software 3 [IF0129] - Uniremington
Patrón: Saga Pattern (Orchestrator), Idempotent Receiver, Fail-Fast con Validaciones
Buenas Prácticas: SoD, Inyección de Dependencias (DIP), Logging Estructurado
Dependencias: NINGUNA (Python Standard Library `time`, `json`, `typing`)
========================================================================================
"""
import time
import json
from src.models import Reserva, ItemReserva, EstadoReserva
from src.interfaces import IServicioRepository, IReservaRepository, IOutboxRepository, IPasarelaPagos
from src.validators import Validator, ValidationError
from src.logger import get_logger

logger = get_logger("Services")


class GimnasioService:
    """
    Servicio de Dominio del Gimnasio.
    Aplica Single Responsibility Principle (SRP) y depende solo de interfaces (DIP).
    """
    def __init__(self,
                 servicio_repo: IServicioRepository,
                 reserva_repo: IReservaRepository,
                 outbox_repo: IOutboxRepository):
        self.servicio_repo = servicio_repo
        self.reserva_repo = reserva_repo
        self.outbox_repo = outbox_repo

    def listar_catalogo(self):
        """Consulta el catálogo completo de servicios del gimnasio."""
        return self.servicio_repo.obtener_todos()

    def crear_reserva_monolito(self,
                               socio_id: str,
                               socio_nombre: str,
                               contacto: str,
                               items_req: list,
                               idempotency_key: str) -> Reserva:
        """
        ====================================================================================
        FLUJO BASE LOCAL (Validación Defensiva + Idempotencia + Semantic Lock + Outbox):
        Etapa 1: Validación estricta Fail-Fast (Sintaxis y Contratos).
        Etapa 2: Comprobación de Idempotencia (Deduplicación).
        Etapa 3: Verificación de cupos y construcción de ítems.
        Etapa 4: Creación del agregado Reserva en estado con bloqueo semántico.
        Etapa 5: Descuento de cupos.
        Etapa 6: Registro en Transactional Outbox (Prevención Dual-Write).
        ====================================================================================
        """
        # --- ETAPA 1: VALIDACIÓN FAIL-FAST ---
        s_id = Validator.validar_socio_id(socio_id)
        s_nombre = Validator.validar_no_vacio(socio_nombre, "socio_nombre")
        s_contacto = Validator.validar_no_vacio(contacto, "contacto")
        i_key = Validator.validar_idempotency_key(idempotency_key)
        items_validados = Validator.validar_items_reserva(items_req)

        # --- ETAPA 2: COMPROBACIÓN DE IDEMPOTENCIA ---
        logger.info(f"Procesando reserva para socio={s_id} con key={i_key}")
        existente = self.reserva_repo.buscar_por_idempotency_key(i_key)
        if existente:
            logger.warning(f"⚠️ [Idempotencia] Petición duplicada detectada. Retornando reserva existente {existente.id_reserva}")
            return existente

        # --- ETAPA 3: VERIFICACIÓN DE CUPOS Y CONSTRUCCIÓN DE ITEMS ---
        items = []
        for it in items_validados:
            serv = self.servicio_repo.buscar_por_codigo(it["codigo"])
            if not serv:
                logger.error(f"Validación de catálogo fallida: el código '{it['codigo']}' no existe.")
                raise ValidationError(f"El servicio '{it['codigo']}' no existe en el catálogo del gimnasio.", campo="codigo")

            if not serv.tiene_cupo(it["cantidad"]):
                logger.error(f"Cupos insuficientes para {serv.nombre} ({serv.codigo}). Solicitado: {it['cantidad']}, Disponible: {serv.cupos_disponibles}")
                raise ValidationError(
                    f"Cupos insuficientes para '{serv.nombre}'. Solicitado: {it['cantidad']}, Disponible: {serv.cupos_disponibles}",
                    campo="cupos"
                )
            items.append(ItemReserva(serv.codigo, it["cantidad"], serv.precio))

        # --- ETAPA 4: INSTANCIACIÓN DEL AGREGADO RESERVA ---
        reserva = Reserva(
            id_reserva=f"RES-{int(time.time() * 1000)}",
            socio_id=s_id,
            socio_nombre=s_nombre,
            socio_contacto=s_contacto,
            items=items,
            estado=EstadoReserva.PENDIENTE,
            idempotency_key=i_key
        )
        reserva.calcular_total()
        reserva.transicionar_a(EstadoReserva.CUPO_RESERVADO_SEMANTIC_LOCK, "Cupo reservado preventivamente (Semantic Lock)")

        # --- ETAPA 5: DESCUENTO DE CUPOS ---
        for it in items:
            serv = self.servicio_repo.buscar_por_codigo(it.servicio_codigo)
            nuevos_cupos = serv.cupos_disponibles - it.cantidad
            self.servicio_repo.actualizar_cupos(serv.codigo, nuevos_cupos)
            logger.debug(f"Cupos actualizados para {serv.codigo}: {serv.cupos_disponibles} -> {nuevos_cupos}")

        # Persistir Reserva con estado CUPO_RESERVADO_SEMANTIC_LOCK
        self.reserva_repo.guardar(reserva)
        logger.info(f"✅ Reserva {reserva.id_reserva} registrada exitosamente. Total=${reserva.total:,.2f}")

        # --- ETAPA 6: TRANSACTIONAL OUTBOX (PREVENCIÓN DUAL-WRITE) ---
        evento_payload = {
            "id_reserva": reserva.id_reserva,
            "socio_id": reserva.socio_id,
            "total": reserva.total,
            "items_count": len(reserva.items),
            "idempotency_key": reserva.idempotency_key,
            "timestamp": reserva.timestamp
        }
        self.outbox_repo.registrar_evento(
            aggregate_id=reserva.id_reserva,
            event_type="co.edu.uniremington.gymexpress.reserva.creada.v1",
            payload_json=json.dumps(evento_payload)
        )
        logger.debug(f"Evento Outbox emitido para reserva {reserva.id_reserva}")

        return reserva


class PasarelaPagosMock(IPasarelaPagos):
    """
    Simulador de Pasarela Financiera Externa (Mock).
    Soporta idempotencia en cobros y simulación deliberada de fallos para probar la Saga.
    """
    def __init__(self):
        self.cobros_procesados = {}

    def procesar_cobro(self, id_reserva: str, monto: float, idempotency_key: str, simular_falla: bool = False) -> bool:
        Validator.validar_monto(monto, "monto_cobro")

        if idempotency_key in self.cobros_procesados:
            logger.info(f"[Pasarela] Cobro idempotente ya registrado para key={idempotency_key}")
            return self.cobros_procesados[idempotency_key]["exito"]

        if simular_falla:
            logger.warning(f"❌ [Pasarela] Cobro RECHAZADO deliberadamente para reserva {id_reserva} (${monto:,.2f})")
            self.cobros_procesados[idempotency_key] = {"exito": False, "monto": monto, "motivo": "Fondos insuficientes"}
            return False

        logger.info(f"💳 [Pasarela] Cobro APROBADO para reserva {id_reserva} (${monto:,.2f})")
        self.cobros_procesados[idempotency_key] = {"exito": True, "monto": monto, "motivo": "Aprobado"}
        return True

    def reembolsar(self, id_reserva: str, monto: float) -> bool:
        logger.info(f"↩️ [Pasarela] Reembolso procesado para reserva {id_reserva} por ${monto:,.2f}")
        return True


class SagaOrquestadorReserva:
    """
    Orquestador Centralizado de Saga:
    Coordina transacciones compensables con garantía de consistencia eventual.
    Pasos:
      - T1: Reserva de cupo (Acción Compensable)
      - T2: Pasarela de Pagos (Punto de Decisión Pivot)
      - T3: Facturación y confirmación (Acción Retriable)
      - C1: Compensación Inversa (Devolución de cupos si T2 falla)
    """
    def __init__(self, gimnasio_service: GimnasioService, pasarela: IPasarelaPagos):
        self.gimnasio_service = gimnasio_service
        self.pasarela = pasarela

    def ejecutar_saga_reserva(self,
                              socio_id: str,
                              socio_nombre: str,
                              contacto: str,
                              items_req: list,
                              idempotency_key: str,
                              simular_falla_pago: bool = False) -> dict:
        """Ejecuta el flujo orquestado de la Saga con compensación automática."""
        log_saga = []
        reserva = None
        logger.info(f"🏁 Iniciando Saga para reserva del socio={socio_id}")

        try:
            # PASO T1: Crear Reserva y Bloquear Cupo (Local con Semantic Lock)
            reserva = self.gimnasio_service.crear_reserva_monolito(
                socio_id, socio_nombre, contacto, items_req, idempotency_key
            )
            msg_t1 = f"T1 [Cupos]: Reserva {reserva.id_reserva} creada con Semantic Lock (Total: ${reserva.total:,.2f})."
            log_saga.append(msg_t1)
            logger.info(msg_t1)

            # Si la reserva ya estaba completada o compensada previamente (idempotencia)
            if reserva.estado in [EstadoReserva.COMPLETADO, EstadoReserva.COMPENSADO]:
                log_saga.append(f"ℹ️ [Idempotencia]: Reserva ya procesada previamente con estado {reserva.estado.value}.")
                return {"exito": reserva.estado == EstadoReserva.COMPLETADO, "reserva": reserva, "log": log_saga}

            # PASO T2: Cobro en Pasarela Externa (Pivot Transaction)
            pay_key = f"PAY-{idempotency_key}"
            pago_ok = self.pasarela.procesar_cobro(
                reserva.id_reserva, reserva.total, pay_key, simular_falla=simular_falla_pago
            )
            if not pago_ok:
                raise RuntimeError("Falla en Pasarela de Pagos (Rechazo Financiero). Disparando Compensación Inversa (C1).")

            reserva.transicionar_a(EstadoReserva.PAGADO, "Cobro aprobado por pasarela financiera")
            self.gimnasio_service.reserva_repo.guardar(reserva)
            msg_t2 = f"T2 [Pagos]: Débito de ${reserva.total:,.2f} exitoso en pasarela."
            log_saga.append(msg_t2)
            logger.info(msg_t2)

            # PASO T3: Facturación y Confirmación de la reserva
            reserva.transicionar_a(EstadoReserva.COMPLETADO, "Reserva facturada y confirmada")
            self.gimnasio_service.reserva_repo.guardar(reserva)
            msg_t3 = "T3 [Facturación]: Factura emitida. Reserva confirmada. Saga completada exitosamente."
            log_saga.append(msg_t3)
            logger.info(msg_t3)

            return {"exito": True, "reserva": reserva, "log": log_saga}

        except ValidationError:
            # Errores de validación se propagan (la capa web los traduce a HTTP 422);
            # no hay nada que compensar porque nunca se bloqueó un cupo.
            raise

        except Exception as e:
            # COMPENSACIÓN INVERSA (C1): deshacer efectos secundarios
            err_msg = f"🚨 ERROR EN SAGA: {str(e)}"
            log_saga.append(err_msg)
            logger.error(err_msg)

            if reserva is not None:
                logger.warning(f"Iniciando Compensación C1 para Reserva {reserva.id_reserva}...")

                # C1: Devolver cupos al servicio
                for it in reserva.items:
                    serv = self.gimnasio_service.servicio_repo.buscar_por_codigo(it.servicio_codigo)
                    if serv:
                        cupos_restaurados = serv.cupos_disponibles + it.cantidad
                        self.gimnasio_service.servicio_repo.actualizar_cupos(serv.codigo, cupos_restaurados)
                        logger.info(f"↩️ C1: Cupos restaurados para {serv.codigo}: {serv.cupos_disponibles} -> {cupos_restaurados}")

                reserva.transicionar_a(EstadoReserva.COMPENSADO, f"Aborto por falla en paso T2: {str(e)}")
                self.gimnasio_service.reserva_repo.guardar(reserva)
                msg_c1 = "C1 [Compensación Cupos]: Cupos devueltos al gimnasio. Estado: COMPENSADO."
                log_saga.append(msg_c1)
                logger.info(msg_c1)

            return {"exito": False, "reserva": reserva, "log": log_saga, "error": str(e)}
